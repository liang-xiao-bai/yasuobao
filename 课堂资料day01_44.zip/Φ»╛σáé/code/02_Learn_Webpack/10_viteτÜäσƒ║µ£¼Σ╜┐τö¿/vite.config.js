const vue = require('@vitejs/plugin-vue')

module.exports = {
  plugins: [
    vue()
  ]
}