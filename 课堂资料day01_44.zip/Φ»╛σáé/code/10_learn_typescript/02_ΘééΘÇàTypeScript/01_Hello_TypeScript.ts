let message: string = 'hello typescript'

function foo(payload: string) {
  console.log(payload.length)
}

// foo(123)
foo("aaa")
