const name: string = "abc"
const age: number = 18

console.log(name)
console.log(age)

export {}
