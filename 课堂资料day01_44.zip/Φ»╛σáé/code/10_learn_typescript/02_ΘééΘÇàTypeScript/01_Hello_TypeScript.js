var message = 'hello typescript';
function foo(payload) {
    console.log(payload.length);
}
foo(123);
foo("aaa");
